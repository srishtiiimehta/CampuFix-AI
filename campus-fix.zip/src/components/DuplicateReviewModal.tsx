import React from 'react';
import { DuplicateMatch, Ticket } from '../types/ticket';
import { StatusBadge, PriorityBadge, CategoryIcon } from './Badge';
import { 
  CopyCheck, 
  CheckCircle2, 
  MapPin, 
  Users, 
  ArrowRight, 
  AlertCircle, 
  PlusCircle, 
  ShieldCheck,
  Compass
} from 'lucide-react';

interface DuplicateReviewModalProps {
  duplicates: DuplicateMatch[];
  candidateTicket: {
    category: string;
    issueSummary: string;
    reportedLocation: string;
    priority: string;
  };
  onTrackExisting: (existingTicketId: string) => void;
  onSubmitSeparate: () => void;
  onCancel: () => void;
  isSubmitting: boolean;
}

export const DuplicateReviewModal: React.FC<DuplicateReviewModalProps> = ({
  duplicates,
  candidateTicket,
  onTrackExisting,
  onSubmitSeparate,
  onCancel,
  isSubmitting,
}) => {
  const hasDuplicates = duplicates.length > 0;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-[20px] border border-[#DCE6F0] p-6">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#0D9488] uppercase tracking-wider">
          <span>Step 4 of 4</span>
          <span aria-hidden="true">·</span>
          <span>Duplicate Review & Submission</span>
        </div>
        <h1 className="text-xl md:text-2xl font-bold text-[#17324F] mt-1">
          {hasDuplicates ? 'Similar Campus Reports Found' : 'No Duplicates Found'}
        </h1>
        <p className="text-xs md:text-sm text-[#17324F]/70 mt-1">
          {hasDuplicates
            ? 'Gemini identified active tickets that may cover your issue. You can subscribe to track an existing repair, or submit a separate work order if this is an independent problem.'
            : 'Your report appears to be a new and unique campus maintenance issue. Ready to create an official work order.'}
        </p>
      </div>

      {/* Your Proposed Ticket Summary */}
      <div className="bg-[#F3F7FB] rounded-[20px] border border-[#DCE6F0] p-4 text-xs">
        <span className="font-semibold text-[#17324F] block mb-1">Your Report:</span>
        <div className="text-[#17324F] font-medium text-sm">{candidateTicket.issueSummary}</div>
        <div className="flex items-center gap-2 text-[#17324F]/70 mt-1">
          <MapPin className="w-3.5 h-3.5 text-[#0D9488]" />
          <span>{candidateTicket.reportedLocation}</span>
          <span className="text-slate-300" aria-hidden="true">·</span>
          <span>{candidateTicket.category}</span>
        </div>
      </div>

      {/* List of Matched Tickets */}
      {hasDuplicates ? (
        <div className="space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-[#17324F]/70">
            Matching Active Tickets ({duplicates.length})
          </div>

          {duplicates.map(({ ticket, similarityScore, matchReason }) => (
            <div
              key={ticket.ticketId}
              className="bg-white rounded-[20px] border-2 border-[#0D9488]/40 p-5 shadow-xs space-y-4"
            >
              {/* Match Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#DCE6F0]">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100 text-teal-900 border border-teal-300 tabular-nums">
                    {similarityScore}% Match
                  </span>
                  <span className="text-xs font-mono text-[#17324F]/70 font-medium">
                    {ticket.ticketId}
                  </span>
                  <span className="text-slate-300" aria-hidden="true">·</span>
                  <StatusBadge status={ticket.status} />
                  <PriorityBadge priority={ticket.priority} />
                </div>

                <div className="text-xs text-slate-400 font-mono">
                  Reported {new Date(ticket.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                </div>
              </div>

              {/* Match Reason Rationale from Gemini */}
              <div className="p-3.5 rounded-[14px] bg-teal-50/60 border border-teal-100 text-xs text-teal-950 flex items-start gap-2">
                <CopyCheck className="w-4 h-4 text-[#0D9488] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold">Why this matches: </span>
                  {matchReason}
                </div>
              </div>

              {/* Existing Ticket Summary */}
              <div>
                <h3 className="text-sm font-bold text-[#17324F]">
                  {ticket.issueSummary}
                </h3>
                <div className="flex items-center gap-1.5 text-xs text-[#17324F]/70 mt-1">
                  <MapPin className="w-3.5 h-3.5 text-[#0D9488] shrink-0" />
                  <span>{ticket.reportedLocation}</span>
                  <span className="text-slate-300" aria-hidden="true">·</span>
                  <span>{ticket.assignedDepartment}</span>
                </div>
              </div>

              {/* Latest Status Note */}
              {ticket.statusHistory && ticket.statusHistory.length > 0 && (
                <div className="text-xs text-[#17324F]/80 bg-[#F3F7FB] p-2.5 rounded-[14px] border border-[#DCE6F0]">
                  <span className="font-semibold text-[#17324F]">Latest Update: </span>
                  {ticket.statusHistory[ticket.statusHistory.length - 1].notes}
                  <span className="text-[#17324F]/60 text-[11px] ml-1">
                    ({ticket.statusHistory[ticket.statusHistory.length - 1].updatedBy})
                  </span>
                </div>
              )}

              {/* Action Buttons for this Duplicate */}
              <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-[#DCE6F0]">
                <div className="flex items-center gap-1.5 text-xs text-[#17324F]/70">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  <span>{ticket.trackedBy?.length || 1} students subscribed to this ticket</span>
                </div>

                <button
                  type="button"
                  onClick={() => onTrackExisting(ticket.ticketId)}
                  disabled={isSubmitting}
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-[#0D9488] hover:bg-[#0B7C72] text-white font-semibold text-xs transition-all cursor-pointer shadow-xs active:scale-[0.99]"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Track This Existing Issue (Recommended)</span>
                </button>
              </div>
            </div>
          ))}

          {/* Fallback Option: Submit Separate */}
          <div className="bg-white rounded-[20px] border border-[#DCE6F0] p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-bold text-[#17324F]">Is this a distinct problem?</div>
              <p className="text-xs text-[#17324F]/70 mt-0.5">
                If your defect is in a different room, equipment, or separate location, you can submit an independent ticket.
              </p>
            </div>
            <button
              type="button"
              onClick={onSubmitSeparate}
              disabled={isSubmitting}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full bg-[#123456] hover:bg-[#0E2A47] text-white text-xs font-semibold whitespace-nowrap cursor-pointer transition-all shadow-xs active:scale-[0.99]"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Submit Separate Ticket</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-[20px] border border-[#DCE6F0] p-8 text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#17324F]">No Existing Duplicates Found</h3>
            <p className="text-xs text-[#17324F]/70 mt-1 max-w-md mx-auto">
              Our campus records show no open work orders for this area. Your ticket will be dispatched immediately to {candidateTicket.category} crews.
            </p>
          </div>

          <div className="pt-2 flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={onCancel}
              className="px-5 py-2.5 text-xs font-semibold text-[#123456] bg-white border border-[#DCE6F0] hover:bg-[#F3F7FB] rounded-full transition-all cursor-pointer shadow-2xs hover:shadow-xs active:scale-[0.99]"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={onSubmitSeparate}
              disabled={isSubmitting}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#0D9488] hover:bg-[#0B7C72] text-white font-semibold text-xs sm:text-sm shadow-xs transition-all focus:outline-none focus:ring-2 focus:ring-[#0D9488] cursor-pointer active:scale-[0.99]"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{isSubmitting ? 'Submitting Ticket...' : 'Confirm & Submit Ticket'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
