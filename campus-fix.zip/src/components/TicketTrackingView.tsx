import React, { useState } from 'react';
import { Ticket } from '../types/ticket';
import { StatusBadge, PriorityBadge, CategoryIcon, HazardNotice } from './Badge';
import { BeforeAfterSlider } from './BeforeAfterSlider';
import { SAMPLE_CAMPUS_PHOTOS, SAMPLE_RESOLVED_PHOTOS } from '../services/sampleImages';
import { soundFx } from '../services/soundFx';
import { 
  ArrowLeft, 
  Clock, 
  MapPin, 
  Building2, 
  CheckCircle2, 
  AlertCircle, 
  MessageSquare, 
  Send, 
  Users, 
  Camera, 
  ShieldCheck,
  FileText,
  Cpu,
  Star,
  ThumbsUp,
  Check
} from 'lucide-react';

interface TicketTrackingViewProps {
  ticket: Ticket;
  currentUserRole: 'student' | 'staff';
  currentUserName: string;
  onBack: () => void;
  onAddNote: (ticketId: string, message: string) => void;
  isAddingNote: boolean;
  onOpenStaffControls?: () => void;
}

export const TicketTrackingView: React.FC<TicketTrackingViewProps> = ({
  ticket,
  currentUserRole,
  currentUserName,
  onBack,
  onAddNote,
  isAddingNote,
  onOpenStaffControls,
}) => {
  const [newNote, setNewNote] = useState('');
  const [rating, setRating] = useState<number>(5);
  const [hasRated, setHasRated] = useState(false);
  const [extraTrackers, setExtraTrackers] = useState<number>(0);

  const getComparisonImages = () => {
    let beforeImg = ticket.imageUrl;
    let afterImg = '';

    if (ticket.category === 'Cleanliness') {
      beforeImg = beforeImg || SAMPLE_CAMPUS_PHOTOS.find((p) => p.id === 'coffee_spill')?.dataUrl;
      afterImg = SAMPLE_RESOLVED_PHOTOS.coffee_spill;
    } else if (ticket.category === 'Plumbing') {
      beforeImg = beforeImg || SAMPLE_CAMPUS_PHOTOS.find((p) => p.id === 'pipe_leak')?.dataUrl;
      afterImg = SAMPLE_RESOLVED_PHOTOS.pipe_leak;
    } else if (ticket.category === 'Electricity') {
      beforeImg = beforeImg || SAMPLE_CAMPUS_PHOTOS.find((p) => p.id === 'light_flicker')?.dataUrl;
      afterImg = SAMPLE_RESOLVED_PHOTOS.light_flicker;
    } else {
      beforeImg = beforeImg || SAMPLE_CAMPUS_PHOTOS.find((p) => p.id === 'wifi_drop')?.dataUrl;
      afterImg = SAMPLE_RESOLVED_PHOTOS.wifi_drop;
    }
    return { beforeImg: beforeImg || '', afterImg: afterImg || '' };
  };

  const handlePostNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim() || isAddingNote) return;
    soundFx.click();
    onAddNote(ticket.ticketId, newNote.trim());
    setNewNote('');
  };

  // Stepper calculations
  const steps = [
    { key: 'Open', label: 'Reported & Queued', desc: 'Ticket logged and assigned to department' },
    { key: 'In Progress', label: 'In Progress', desc: 'Facility crew dispatched & diagnostics underway' },
    { key: 'Resolved', label: 'Resolved', desc: 'Repairs completed and verified by supervisor' },
  ];

  const currentStepIndex = ticket.status === 'Open' ? 0 : ticket.status === 'In Progress' ? 1 : 2;
  const comparison = getComparisonImages();

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Top Navigation & Community Reinforce Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <button
          onClick={() => {
            soundFx.click();
            onBack();
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#123456] bg-white border border-[#DCE6F0] hover:bg-[#F3F7FB] px-4 py-2 rounded-full transition-all cursor-pointer shadow-2xs hover:shadow-xs active:scale-[0.99] self-start"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>

        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          {/* Community +1 Affected Upvote */}
          <button
            type="button"
            onClick={() => {
              soundFx.upvote();
              setExtraTrackers((prev) => prev + 1);
            }}
            title="Indicate that you are also affected by this maintenance problem"
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-full border border-[#DCE6F0] bg-white hover:bg-[#F3F7FB] text-[#17324F] transition-all cursor-pointer shadow-2xs hover:shadow-xs active:scale-95"
          >
            <ThumbsUp className="w-3.5 h-3.5 text-[#0D9488]" />
            <span>I'm Affected Too</span>
            <span className="font-mono text-[11px] px-2 py-0.2 rounded-full bg-[#F3F7FB] text-[#0D9488] font-bold border border-[#DCE6F0]">
              {(ticket.trackedBy?.length || 1) + extraTrackers}
            </span>
          </button>

          {currentUserRole === 'staff' && onOpenStaffControls && (
            <button
              onClick={() => {
                soundFx.click();
                onOpenStaffControls();
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#123456] hover:bg-[#0E2A47] text-white text-xs font-semibold shadow-xs transition-all cursor-pointer active:scale-[0.99]"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#0D9488]" />
              <span>Open Staff Resolution Controls</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Ticket Card Header */}
      <div className="bg-white rounded-[20px] border border-[#DCE6F0] overflow-hidden shadow-xs">
        {/* Navy Header Strip */}
        <div className="bg-[#123456] text-white p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono text-xs font-bold text-[#0D9488] tracking-wider">
                {ticket.ticketId}
              </span>

              {ticket.isDemo && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#17324F] text-[#0D9488] border border-white/10">
                  DEMO RECORD
                </span>
              )}

              <span className="text-slate-400" aria-hidden="true">·</span>

              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                <CategoryIcon category={ticket.category} className="w-4 h-4" />
                <span>{ticket.category}</span>
              </div>

              <span className="text-slate-400" aria-hidden="true">·</span>

              <StatusBadge status={ticket.status} />

              <PriorityBadge priority={ticket.priority} />
            </div>

            <div className="text-xs text-slate-300 font-mono">
              Created {new Date(ticket.createdAt).toLocaleString(undefined, {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </div>
          </div>

          <h1 className="text-xl md:text-2xl font-bold text-white mt-4 leading-snug">
            {ticket.issueSummary}
          </h1>

          <div className="flex items-center gap-2 text-xs text-slate-200 mt-2">
            <MapPin className="w-3.5 h-3.5 text-[#0D9488] shrink-0" />
            <span className="font-medium text-white">{ticket.reportedLocation}</span>
            <span className="text-slate-400" aria-hidden="true">·</span>
            <span className="text-slate-200">Dept: {ticket.assignedDepartment}</span>
          </div>
        </div>

        {/* 3-Step Visual Progress Stepper */}
        <div className="p-6 bg-[#F3F7FB] border-b border-[#DCE6F0]">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {steps.map((step, idx) => {
              const isCompleted = idx < currentStepIndex;
              const isCurrent = idx === currentStepIndex;

              return (
                <div
                  key={step.key}
                  className={`p-3.5 rounded-[16px] border transition-all ${
                    isCurrent
                      ? 'bg-white border-[#0D9488] shadow-xs'
                      : isCompleted
                      ? 'bg-emerald-50/50 border-emerald-200'
                      : 'bg-slate-100/70 border-[#DCE6F0] opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                        isCurrent
                          ? 'bg-[#0D9488] text-white'
                          : isCompleted
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-300 text-slate-700'
                      }`}
                    >
                      {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                    </div>
                    <span className="text-xs font-bold text-[#17324F]">{step.label}</span>
                  </div>
                  <p className="text-[11px] text-[#17324F]/70 mt-1 pl-8 leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Resolution Banner (if Resolved) */}
        {ticket.status === 'Resolved' && (
          <div className="p-6 bg-emerald-50 border-b border-emerald-200">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="text-xs font-bold uppercase tracking-wider text-emerald-900">
                  Ticket Resolved & Verified by Facilities
                </div>
                <p className="text-sm text-emerald-950 font-medium leading-relaxed">
                  {ticket.resolutionNotes || 'All work completed, verified, and inspected according to university facility standards.'}
                </p>
                <div className="text-xs text-emerald-700 font-mono mt-1">
                  Resolved on: {new Date(ticket.updatedAt).toLocaleString()}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Safety Warning (if Hazard) */}
        {ticket.isSafetyHazard && (
          <div className="p-6 border-b border-[#DCE6F0]">
            <HazardNotice warning={ticket.safetyWarning} />
          </div>
        )}

        {/* Observation & Evidence Grid */}
        <div className="p-6 space-y-6">
          <div className="text-xs font-bold uppercase tracking-wider text-[#17324F]/70">
            Diagnostic Record & Observations
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Student Facts */}
            <div className="p-4 rounded-[16px] bg-[#F3F7FB] border border-[#DCE6F0]">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#17324F] mb-2">
                <FileText className="w-4 h-4 text-[#0D9488]" />
                <span>Student-Reported Facts</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-xs text-[#17324F]/80">
                {ticket.studentProvidedFacts && ticket.studentProvidedFacts.length > 0 ? (
                  ticket.studentProvidedFacts.map((fact, idx) => <li key={idx}>{fact}</li>)
                ) : (
                  <li>{ticket.issueSummary}</li>
                )}
              </ul>
            </div>

            {/* AI Inferences */}
            <div className="p-4 rounded-[16px] bg-[#F3F7FB] border border-[#DCE6F0]">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#17324F] mb-2">
                <Cpu className="w-4 h-4 text-[#0D9488]" />
                <span>AI Engineering Inferences</span>
              </div>
              <ul className="space-y-1 text-xs text-[#17324F]/80">
                {ticket.aiInferences && ticket.aiInferences.length > 0 ? (
                  ticket.aiInferences.map((inf, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-[#0D9488] font-bold">›</span>
                      <span>{inf}</span>
                    </li>
                  ))
                ) : (
                  <li>Assigned to {ticket.assignedDepartment}.</li>
                )}
              </ul>
            </div>
          </div>

          {/* Resolved Proof-of-Fix Before / After Slider */}
          {ticket.status === 'Resolved' && comparison.beforeImg && comparison.afterImg && (
            <div className="space-y-4">
              <BeforeAfterSlider
                beforeImage={comparison.beforeImg}
                afterImage={comparison.afterImg}
                beforeLabel="Reported Defect (Before)"
                afterLabel="Facility Verified Restored (After)"
                notes={ticket.resolutionNotes || 'Technician signed off and verified safe.'}
              />

              {/* Student 5-Star Experience Rating Widget */}
              <div className="p-4 rounded-[16px] bg-[#F3F7FB] border border-[#DCE6F0] space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-[#17324F] flex items-center gap-1.5">
                    <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                    <span>Rate Facility Resolution Quality & Turnaround</span>
                  </div>
                  {hasRated && (
                    <span className="text-[10px] font-mono text-emerald-700 font-bold bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                      ✓ Feedback Submitted
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((starIdx) => (
                    <button
                      key={starIdx}
                      type="button"
                      onClick={() => {
                        soundFx.star(starIdx);
                        setRating(starIdx);
                        setHasRated(true);
                      }}
                      className="p-1 text-slate-300 hover:text-amber-400 transition-transform hover:scale-125 cursor-pointer"
                      title={`${starIdx} Stars`}
                    >
                      <Star
                        className={`w-5 h-5 ${
                          starIdx <= rating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-slate-300'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs font-semibold text-[#17324F] ml-2">
                    {rating === 5
                      ? '5/5 · Excellent, swift turnaround'
                      : rating === 4
                      ? '4/5 · Great repair quality'
                      : `${rating}/5 Stars`}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Optional Photo Attachment if Not Resolved */}
          {ticket.status !== 'Resolved' && ticket.imageUrl && (
            <div className="p-4 rounded-[16px] bg-[#F3F7FB] border border-[#DCE6F0]">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#17324F] mb-3">
                <Camera className="w-4 h-4 text-indigo-600" />
                <span>Attached Photographic Evidence</span>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 items-start">
                <img
                  src={ticket.imageUrl}
                  alt="Inspection Evidence"
                  className="w-48 h-36 object-cover rounded-[14px] border border-[#DCE6F0]"
                />
                <div className="text-xs text-[#17324F]/80 leading-relaxed">
                  <span className="font-semibold text-[#17324F] block mb-1">Visual Analysis:</span>
                  {ticket.imageObservations || 'Inspection visual data confirms defect matching description.'}
                </div>
              </div>
            </div>
          )}

          {/* Tracked by other students */}
          {ticket.trackedBy && ticket.trackedBy.length > 1 && (
            <div className="p-3.5 rounded-[16px] bg-[#F3F7FB] border border-[#DCE6F0] flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-[#17324F]">
                <Users className="w-4 h-4 text-slate-500" />
                <span className="font-semibold">
                  {ticket.trackedBy.length} Students Tracking This Issue
                </span>
              </div>
              <span className="text-[#17324F]/60 font-mono text-[11px]">Consolidated Single Work Order</span>
            </div>
          )}
        </div>
      </div>

      {/* Status History Timeline */}
      <div className="bg-white rounded-[20px] border border-[#DCE6F0] p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-[#DCE6F0]">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#0D9488]" />
            <h2 className="text-sm font-bold text-[#17324F] uppercase tracking-wider">
              Status History & Audit Trail
            </h2>
          </div>
          <span className="text-xs text-[#17324F]/60 font-mono">
            {ticket.statusHistory?.length || 0} events recorded
          </span>
        </div>

        <div className="mt-6 space-y-6 relative before:absolute before:inset-0 before:left-3 before:w-0.5 before:bg-[#DCE6F0]">
          {ticket.statusHistory?.map((hist, idx) => (
            <div key={hist.id || idx} className="relative flex items-start gap-4 pl-2">
              <div className="w-3 h-3 rounded-full bg-[#0D9488] ring-4 ring-white shrink-0 mt-1" />
              <div className="flex-1 bg-[#F3F7FB] rounded-[14px] p-3.5 border border-[#DCE6F0]">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
                  <div className="flex items-center gap-2">
                    <StatusBadge status={hist.status} size="sm" />
                    <span className="font-bold text-[#17324F]">{hist.updatedBy}</span>
                    <span className="text-[#17324F]/60">({hist.role})</span>
                  </div>
                  <span className="text-[#17324F]/60 font-mono text-[11px]">
                    {new Date(hist.timestamp).toLocaleString()}
                  </span>
                </div>
                <p className="text-xs text-[#17324F]/80 mt-2 leading-relaxed">
                  {hist.notes}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Discussion & Updates Thread */}
      <div className="bg-white rounded-[20px] border border-[#DCE6F0] p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#DCE6F0]">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-[#0D9488]" />
            <h2 className="text-sm font-bold text-[#17324F] uppercase tracking-wider">
              Ticket Discussion & Field Notes
            </h2>
          </div>
          <span className="text-xs text-[#17324F]/60">
            {ticket.notesThread?.length || 0} messages
          </span>
        </div>

        {/* Existing Thread Messages */}
        <div className="space-y-3">
          {ticket.notesThread && ticket.notesThread.length > 0 ? (
            ticket.notesThread.map((n) => (
              <div
                key={n.id}
                className={`p-3.5 rounded-[14px] text-xs leading-relaxed border ${
                  n.role === 'staff'
                    ? 'bg-[#123456] text-white border-[#123456]'
                    : 'bg-[#F3F7FB] text-[#17324F] border-[#DCE6F0]'
                }`}
              >
                <div className="flex items-center justify-between font-medium mb-1">
                  <span className={n.role === 'staff' ? 'text-[#0D9488] font-bold' : 'text-[#17324F] font-semibold'}>
                    {n.author} {n.role === 'staff' ? '(Staff)' : '(Student)'}
                  </span>
                  <span className="text-[11px] opacity-70 font-mono">
                    {new Date(n.timestamp).toLocaleString()}
                  </span>
                </div>
                <p>{n.message}</p>
              </div>
            ))
          ) : (
            <div className="text-xs text-[#17324F]/60 text-center py-4">
              No notes or additional comments yet.
            </div>
          )}
        </div>

        {/* Add Note Form */}
        <form onSubmit={handlePostNote} className="pt-2 flex gap-2">
          <input
            type="text"
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            placeholder={`Add a field note or question as ${currentUserName}...`}
            disabled={isAddingNote}
            className="flex-1 px-3.5 py-2 text-xs rounded-[14px] border border-[#DCE6F0] focus:outline-none focus:ring-2 focus:ring-[#0D9488] text-[#17324F]"
          />
          <button
            type="submit"
            disabled={isAddingNote || !newNote.trim()}
            className="inline-flex items-center gap-1.5 px-5 py-2 rounded-full bg-[#0D9488] hover:bg-[#0B7C72] disabled:opacity-50 text-white font-medium text-xs transition-all cursor-pointer shadow-xs active:scale-[0.99]"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Post Note</span>
          </button>
        </form>
      </div>
    </div>
  );
};
