import React, { useState } from 'react';
import { Sparkles, CheckCircle2, AlertCircle, ArrowLeftRight } from 'lucide-react';
import { soundFx } from '../services/soundFx';

interface BeforeAfterSliderProps {
  beforeImage: string;
  afterImage: string;
  beforeLabel?: string;
  afterLabel?: string;
  notes?: string;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({
  beforeImage,
  afterImage,
  beforeLabel = 'Reported Problem (Before)',
  afterLabel = 'Facility Verified Fix (After)',
  notes = 'Repairs inspected and signed off by campus facility technicians.',
}) => {
  const [sliderPosition, setSliderPosition] = useState<number>(50);
  const [isDragging, setIsDragging] = useState(false);
  const [viewMode, setViewMode] = useState<'slider' | 'sideBySide'>('slider');

  const handleSliderMove = (clientX: number, rect: DOMRect) => {
    const x = clientX - rect.left;
    const clamped = Math.max(5, Math.min(95, (x / rect.width) * 100));
    setSliderPosition(clamped);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    handleSliderMove(e.touches[0].clientX, rect);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging && e.buttons !== 1) return;
    const rect = e.currentTarget.getBoundingClientRect();
    handleSliderMove(e.clientX, rect);
  };

  return (
    <div className="rounded-[20px] bg-white border border-[#DCE6F0] p-5 shadow-xs space-y-4">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-600 font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div>
            <div className="text-xs font-bold text-[#17324F] flex items-center gap-1.5">
              <span>Interactive Proof-of-Fix Comparison</span>
              <span className="text-[10px] font-mono uppercase bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                Verified
              </span>
            </div>
            <p className="text-[11px] text-[#17324F]/70">{notes}</p>
          </div>
        </div>

        {/* View mode toggle */}
        <div className="flex items-center gap-1.5 p-1 bg-[#F3F7FB] rounded-full border border-[#DCE6F0] self-start sm:self-auto">
          <button
            type="button"
            onClick={() => {
              soundFx.click();
              setViewMode('slider');
            }}
            className={`px-3 py-1 text-[11px] font-semibold rounded-full transition-all cursor-pointer ${
              viewMode === 'slider'
                ? 'bg-white text-[#17324F] shadow-xs'
                : 'text-[#17324F]/70 hover:text-[#17324F]'
            }`}
          >
            Sweep Slider
          </button>
          <button
            type="button"
            onClick={() => {
              soundFx.click();
              setViewMode('sideBySide');
            }}
            className={`px-3 py-1 text-[11px] font-semibold rounded-full transition-all cursor-pointer ${
              viewMode === 'sideBySide'
                ? 'bg-white text-[#17324F] shadow-xs'
                : 'text-[#17324F]/70 hover:text-[#17324F]'
            }`}
          >
            Side by Side
          </button>
        </div>
      </div>

      {viewMode === 'slider' ? (
        /* Slider Mode */
        <div className="space-y-2">
          <div
            className="relative h-64 sm:h-80 w-full overflow-hidden rounded-[16px] border border-[#DCE6F0] select-none cursor-ew-resize bg-slate-900"
            onMouseMove={handleMouseMove}
            onMouseDown={() => setIsDragging(true)}
            onMouseUp={() => setIsDragging(false)}
            onTouchMove={handleTouchMove}
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              handleSliderMove(e.clientX, rect);
              soundFx.click();
            }}
          >
            {/* After Image (Full background) */}
            <img
              src={afterImage}
              alt={afterLabel}
              className="absolute inset-0 w-full h-full object-cover pointer-events-none"
            />
            <div className="absolute top-3 right-3 z-10 px-2.5 py-1 rounded-full bg-emerald-950/80 backdrop-blur-xs text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
              AFTER · {afterLabel}
            </div>

            {/* Before Image (Clipped overlay) */}
            <div
              className="absolute inset-y-0 left-0 overflow-hidden pointer-events-none transition-all duration-75"
              style={{ width: `${sliderPosition}%` }}
            >
              <img
                src={beforeImage}
                alt={beforeLabel}
                className="absolute inset-0 w-full h-full object-cover max-w-none"
                style={{ width: '100%', minWidth: '100%' }}
              />
              <div className="absolute top-3 left-3 z-10 px-2.5 py-1 rounded-full bg-rose-950/80 backdrop-blur-xs text-rose-300 text-[10px] font-bold border border-rose-500/30">
                BEFORE · {beforeLabel}
              </div>
            </div>

            {/* Drag Handle Divider */}
            <div
              className="absolute inset-y-0 w-1 bg-white shadow-[0_0_12px_rgba(0,0,0,0.6)] cursor-ew-resize"
              style={{ left: `${sliderPosition}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white border-2 border-[#123456] shadow-md flex items-center justify-center text-[#123456]">
                <ArrowLeftRight className="w-4 h-4 text-[#123456]" />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-[#17324F]/60 px-1 font-mono">
            <span>‹ Slide left to inspect repaired state</span>
            <span>Slide right to see original complaint ›</span>
          </div>
        </div>
      ) : (
        /* Side by Side Mode */
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <div className="text-[11px] font-bold text-rose-600 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{beforeLabel}</span>
            </div>
            <img
              src={beforeImage}
              alt={beforeLabel}
              className="h-48 sm:h-56 w-full object-cover rounded-[14px] border border-[#DCE6F0]"
            />
          </div>

          <div className="space-y-1.5">
            <div className="text-[11px] font-bold text-emerald-600 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{afterLabel}</span>
            </div>
            <img
              src={afterImage}
              alt={afterLabel}
              className="h-48 sm:h-56 w-full object-cover rounded-[14px] border border-emerald-300/40"
            />
          </div>
        </div>
      )}
    </div>
  );
};
