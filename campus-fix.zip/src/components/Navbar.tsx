import React, { useState } from 'react';
import { 
  Building2, 
  RotateCcw, 
  ShieldCheck, 
  GraduationCap,
  Sun,
  Moon,
  Volume2,
  VolumeX
} from 'lucide-react';
import { soundFx } from '../services/soundFx';

export type ActivePage = 
  | 'student_dashboard' 
  | 'new_complaint' 
  | 'clarification' 
  | 'review_confirm' 
  | 'duplicate_review' 
  | 'ticket_tracking' 
  | 'staff_dashboard';

export type UserRole = 'student' | 'staff';

interface NavbarProps {
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  onResetDemoData: () => void;
  isResetting: boolean;
  selectedTicketId: string | null;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activePage,
  setActivePage,
  userRole,
  setUserRole,
  onResetDemoData,
  isResetting,
  selectedTicketId,
  theme,
  onToggleTheme,
}) => {
  const [isMuted, setIsMuted] = useState(soundFx.isMuted());

  return (
    <header className="sticky top-0 z-40 theme-navbar border-b transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setActivePage(userRole === 'staff' ? 'staff_dashboard' : 'student_dashboard')}
              className="flex items-center gap-2.5 text-left focus:outline-none group cursor-pointer"
            >
              <div className="w-9 h-9 rounded-full theme-navbar-icon-badge flex items-center justify-center font-bold shadow-xs transition-transform group-hover:scale-105">
                <Building2 className="w-5 h-5 theme-navbar-icon" />
              </div>
              <div>
                <span className="text-lg font-bold tracking-tight theme-navbar-brand-title">
                  CampusFix <span className="theme-navbar-accent font-extrabold">AI</span>
                </span>
                <span className="hidden sm:inline-block ml-2 text-xs font-medium theme-navbar-brand-sub">
                  University Facilities
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
            <button
              onClick={() => setActivePage('student_dashboard')}
              className={`transition-colors whitespace-nowrap py-1 cursor-pointer ${
                activePage === 'student_dashboard'
                  ? 'theme-nav-link-active font-semibold border-b-2'
                  : 'theme-nav-link-inactive'
              }`}
            >
              Student Portal
            </button>

            <button
              onClick={() => setActivePage('new_complaint')}
              className={`transition-colors whitespace-nowrap py-1 cursor-pointer ${
                activePage === 'new_complaint' || activePage === 'clarification' || activePage === 'review_confirm' || activePage === 'duplicate_review'
                  ? 'theme-nav-link-active font-semibold border-b-2'
                  : 'theme-nav-link-inactive'
              }`}
            >
              Report Problem
            </button>

            {selectedTicketId && (
              <button
                onClick={() => setActivePage('ticket_tracking')}
                className={`transition-colors whitespace-nowrap py-1 cursor-pointer ${
                  activePage === 'ticket_tracking'
                    ? 'theme-nav-link-active font-semibold border-b-2'
                    : 'theme-nav-link-inactive'
                }`}
              >
                Track Ticket
              </button>
            )}

            <button
              onClick={() => {
                setUserRole('staff');
                setActivePage('staff_dashboard');
              }}
              className={`transition-colors whitespace-nowrap py-1 cursor-pointer ${
                activePage === 'staff_dashboard'
                  ? 'theme-nav-link-active font-semibold border-b-2'
                  : 'theme-nav-link-inactive'
              }`}
            >
              Staff Console
            </button>
          </nav>

          {/* Zone 3: Primary Action / Role Switcher & Theme Toggle */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Theme Toggle Button */}
            <button
              type="button"
              onClick={() => {
                soundFx.click();
                onToggleTheme();
              }}
              aria-label={theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
              title={theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
              className="theme-toggle-btn inline-flex items-center justify-center w-8 h-8 rounded-full border transition-all cursor-pointer shadow-2xs hover:shadow-xs active:scale-95"
            >
              {theme === 'light' ? (
                <Sun className="w-4 h-4" />
              ) : (
                <Moon className="w-4 h-4" />
              )}
            </button>

            {/* Tactile Audio Feedback Toggle Button */}
            <button
              type="button"
              onClick={() => {
                const nextMuted = soundFx.toggleMute();
                setIsMuted(nextMuted);
                if (!nextMuted) soundFx.click();
              }}
              aria-label={isMuted ? 'Unmute Sound Effects' : 'Mute Sound Effects'}
              title={isMuted ? 'Turn Sound FX On' : 'Mute Sound FX'}
              className="theme-toggle-btn inline-flex items-center justify-center w-8 h-8 rounded-full border transition-all cursor-pointer shadow-2xs hover:shadow-xs active:scale-95"
            >
              {isMuted ? (
                <VolumeX className="w-4 h-4 opacity-70" />
              ) : (
                <Volume2 className="w-4 h-4 text-emerald-400" />
              )}
            </button>

            {/* Quick Demo Reset Button - Outline button styling */}
            <button
              onClick={onResetDemoData}
              disabled={isResetting}
              title="Reset demonstration records (Library WiFi, Chem Lab leak, etc.)"
              className="hidden lg:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium theme-navbar-reset-btn rounded-full border transition-all cursor-pointer shadow-2xs hover:shadow-xs active:scale-[0.99]"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isResetting ? 'animate-spin' : ''}`} />
              <span>{isResetting ? 'Resetting...' : 'Reset Demo Data'}</span>
            </button>

            {/* Role Switcher Segmented Control */}
            <div className="flex items-center p-1 theme-navbar-role-control rounded-full border">
              <button
                onClick={() => {
                  setUserRole('student');
                  if (activePage === 'staff_dashboard') {
                    setActivePage('student_dashboard');
                  }
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-full transition-all whitespace-nowrap cursor-pointer theme-navbar-role-btn-student ${
                  userRole === 'student'
                    ? 'theme-navbar-role-active shadow-xs font-semibold'
                    : 'theme-navbar-role-inactive'
                }`}
              >
                <GraduationCap className="w-3.5 h-3.5" />
                <span>Student</span>
              </button>

              <button
                onClick={() => {
                  setUserRole('staff');
                  setActivePage('staff_dashboard');
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-full transition-all whitespace-nowrap cursor-pointer theme-navbar-role-btn-staff ${
                  userRole === 'staff'
                    ? 'theme-navbar-role-active shadow-xs font-semibold'
                    : 'theme-navbar-role-inactive'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Staff</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
