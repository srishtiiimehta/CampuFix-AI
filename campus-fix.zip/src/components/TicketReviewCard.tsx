import React, { useState } from 'react';
import { AnalysisResult, TicketCategory, TicketPriority, CATEGORY_DEPARTMENT_MAP } from '../types/ticket';
import { StatusBadge, PriorityBadge, CategoryIcon, HazardNotice } from './Badge';
import { AIDiagnosticScanner } from './AIDiagnosticScanner';
import { soundFx } from '../services/soundFx';
import { 
  Building2, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  Edit3, 
  ArrowRight, 
  ArrowLeft, 
  Sparkles,
  FileText,
  Camera,
  Cpu,
  ShieldAlert
} from 'lucide-react';

interface TicketReviewCardProps {
  analysis: AnalysisResult;
  imageUrl?: string;
  onConfirm: (confirmedTicket: {
    category: TicketCategory;
    issueSummary: string;
    reportedLocation: string;
    priority: TicketPriority;
    studentProvidedFacts: string[];
    visualObservations: string[];
    aiInferences: string[];
    isSafetyHazard: boolean;
    safetyWarning?: string;
  }) => void;
  isCheckingDuplicates: boolean;
  onBackToEdit: () => void;
}

export const TicketReviewCard: React.FC<TicketReviewCardProps> = ({
  analysis,
  imageUrl,
  onConfirm,
  isCheckingDuplicates,
  onBackToEdit,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [summary, setSummary] = useState(analysis.issueSummary);
  const [location, setLocation] = useState(analysis.reportedLocation || 'Main Campus');
  const [category, setCategory] = useState<TicketCategory>(analysis.category);
  const [priority, setPriority] = useState<TicketPriority>(analysis.priority);

  const handleProceed = () => {
    onConfirm({
      category,
      issueSummary: summary.trim(),
      reportedLocation: location.trim(),
      priority,
      studentProvidedFacts: analysis.studentProvidedFacts,
      visualObservations: analysis.visualObservations,
      aiInferences: analysis.aiInferences,
      isSafetyHazard: analysis.isSafetyHazard,
      safetyWarning: analysis.safetyWarning,
    });
  };

  const assignedDept = CATEGORY_DEPARTMENT_MAP[category];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-[20px] border border-[#DCE6F0] p-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#0D9488] uppercase tracking-wider">
              <span>Step 3 of 4</span>
              <span aria-hidden="true">·</span>
              <span>Review Structured Maintenance Ticket</span>
            </div>
            <h1 className="text-xl md:text-2xl font-bold text-[#17324F] mt-1">
              Verify Ticket Details
            </h1>
            <p className="text-xs md:text-sm text-[#17324F]/70 mt-1">
              Gemini has structured your informal complaint into an official university work order. Review the categorized information and observations below before checking for duplicates.
            </p>
          </div>

          <button
            onClick={() => setIsEditing(!isEditing)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-[#123456] bg-white hover:bg-[#F3F7FB] border border-[#DCE6F0] rounded-full transition-all cursor-pointer shadow-2xs hover:shadow-xs active:scale-[0.99]"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>{isEditing ? 'Done Editing' : 'Edit Fields'}</span>
          </button>
        </div>
      </div>

      {/* Structured Ticket Container */}
      <div className="bg-white rounded-[20px] border border-[#DCE6F0] overflow-hidden shadow-xs">
        {/* Ticket Title Banner */}
        <div className="bg-[#123456] text-white p-6 border-b border-[#123456]">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-[#0D9488] bg-[#17324F] px-2.5 py-0.5 rounded-full border border-white/10">
                PROPOSED TICKET
              </span>
              <span className="text-xs text-slate-300">· Status:</span>
              <span className="text-xs font-semibold text-amber-300">Open (Draft)</span>
            </div>
            <div className="text-xs font-mono text-slate-300">
              Generated: {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </div>
          </div>

          {/* Issue Summary Display or Edit */}
          {isEditing ? (
            <div className="mt-4 space-y-3">
              <div>
                <label className="text-xs text-slate-200 font-semibold block mb-1">Issue Summary</label>
                <input
                  type="text"
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-[14px] bg-[#17324F] border border-white/20 text-white focus:outline-none focus:border-[#0D9488]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-200 font-semibold block mb-1">Category (1 of 4 Allowed)</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as TicketCategory)}
                    className="w-full px-3 py-2 text-xs rounded-[14px] bg-[#17324F] border border-white/20 text-white focus:outline-none focus:border-[#0D9488]"
                  >
                    <option value="Plumbing">Plumbing</option>
                    <option value="Electricity">Electricity</option>
                    <option value="Cleanliness">Cleanliness</option>
                    <option value="Internet Connectivity">Internet Connectivity</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-200 font-semibold block mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as TicketPriority)}
                    className="w-full px-3 py-2 text-xs rounded-[14px] bg-[#17324F] border border-white/20 text-white focus:outline-none focus:border-[#0D9488]"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Critical">Critical</option>
                  </select>
                </div>
              </div>
            </div>
          ) : (
            <div className="mt-3">
              <h2 className="text-lg md:text-xl font-bold text-white leading-snug">
                {summary}
              </h2>
            </div>
          )}
        </div>

        {/* Core Field Attributes Grid */}
        <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-4 border-b border-[#DCE6F0] bg-[#F3F7FB]">
          <div>
            <span className="text-xs font-medium text-[#17324F]/60 uppercase tracking-wider block">
              Campus Location
            </span>
            {isEditing ? (
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Building, Floor, Room number"
                className="mt-1 w-full px-3 py-1.5 text-xs rounded-[14px] border border-[#DCE6F0] bg-white text-[#17324F]"
              />
            ) : (
              <div className="flex items-center gap-1.5 font-semibold text-[#17324F] text-sm mt-1">
                <MapPin className="w-4 h-4 text-[#0D9488] shrink-0" />
                <span>{location}</span>
              </div>
            )}
          </div>

          <div>
            <span className="text-xs font-medium text-[#17324F]/60 uppercase tracking-wider block">
              Assigned Department
            </span>
            <div className="font-semibold text-[#17324F] text-sm mt-1">
              {assignedDept}
            </div>
            <div className="text-[11px] text-[#17324F]/60">Mapped from {category}</div>
          </div>
        </div>

        {/* Crucial Section: Separation of Observations */}
        <div className="p-6 space-y-5">
          <div className="text-xs font-bold uppercase tracking-wider text-[#17324F]/70 flex items-center justify-between">
            <span>Separation of Observations & Evidence</span>
            <span className="text-[11px] text-[#0D9488] font-mono">Gemini Audit Log</span>
          </div>

          {/* 1. Student Provided Facts */}
          <div className="p-4 rounded-[16px] bg-white border border-[#DCE6F0]">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#17324F] mb-2">
              <FileText className="w-4 h-4 text-[#0D9488]" />
              <span>Student-Provided Facts</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-xs text-[#17324F]/80">
              {analysis.studentProvidedFacts && analysis.studentProvidedFacts.length > 0 ? (
                analysis.studentProvidedFacts.map((fact, i) => <li key={i}>{fact}</li>)
              ) : (
                <li>{summary}</li>
              )}
            </ul>
          </div>

          {/* 2. Visual Observations & Multimodal Scanner */}
          {imageUrl && (
            <div className="space-y-3">
              <AIDiagnosticScanner
                imageUrl={imageUrl}
                category={category}
                observations={analysis.visualObservations}
                inferences={analysis.aiInferences}
              />
            </div>
          )}

          {/* 3. AI Inferences */}
          <div className="p-4 rounded-[16px] bg-teal-50/40 border border-teal-100">
            <div className="flex items-center gap-2 text-xs font-semibold text-teal-900 mb-2">
              <Cpu className="w-4 h-4 text-[#0D9488]" />
              <span>AI Engineering Inferences</span>
            </div>
            <ul className="space-y-1 text-xs text-teal-800">
              {analysis.aiInferences && analysis.aiInferences.length > 0 ? (
                analysis.aiInferences.map((inf, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-[#0D9488] font-bold">›</span>
                    <span>{inf}</span>
                  </li>
                ))
              ) : (
                <li>Assigned to {assignedDept} based on campus facility criteria.</li>
              )}
            </ul>
          </div>

          {/* Safety Warning */}
          {analysis.isSafetyHazard && (
            <HazardNotice warning={analysis.safetyWarning} />
          )}
        </div>

        {/* Action Controls */}
        <div className="p-6 bg-[#F3F7FB] border-t border-[#DCE6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <button
            type="button"
            onClick={onBackToEdit}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-[#123456] bg-white border border-[#DCE6F0] hover:bg-[#F3F7FB] rounded-full transition-all cursor-pointer shadow-2xs hover:shadow-xs active:scale-[0.99]"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Clarification</span>
          </button>

          <button
            type="button"
            onClick={handleProceed}
            disabled={isCheckingDuplicates}
            className="inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-full bg-[#0D9488] hover:bg-[#0B7C72] text-white font-medium text-xs sm:text-sm shadow-xs transition-all focus:outline-none focus:ring-2 focus:ring-[#0D9488] focus:ring-offset-2 cursor-pointer active:scale-[0.99]"
          >
            <Sparkles className={`w-4 h-4 ${isCheckingDuplicates ? 'animate-spin' : ''}`} />
            <span>
              {isCheckingDuplicates ? 'Scanning Active Campus Tickets...' : 'Check for Existing Duplicates & Proceed'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
