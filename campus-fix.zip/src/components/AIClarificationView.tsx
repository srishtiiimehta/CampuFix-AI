import React, { useState } from 'react';
import { AnalysisResult, ClarificationMessage } from '../types/ticket';
import { StatusBadge, PriorityBadge, CategoryIcon, HazardNotice } from './Badge';
import { soundFx } from '../services/soundFx';
import { 
  Sparkles, 
  Send, 
  MapPin, 
  CheckCircle2, 
  HelpCircle, 
  AlertTriangle,
  ArrowRight,
  RefreshCw,
  MessageSquare
} from 'lucide-react';

interface AIClarificationViewProps {
  currentAnalysis: AnalysisResult;
  messages: ClarificationMessage[];
  onSendMessage: (replyText: string) => void;
  isLoading: boolean;
  onProceedToReview: () => void;
  onRestart: () => void;
}

export const AIClarificationView: React.FC<AIClarificationViewProps> = ({
  currentAnalysis,
  messages,
  onSendMessage,
  isLoading,
  onProceedToReview,
  onRestart,
}) => {
  const [replyText, setReplyText] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || isLoading) return;
    soundFx.click();
    onSendMessage(replyText.trim());
    setReplyText('');
  };

  const handleQuickAnswer = (answer: string) => {
    soundFx.click();
    onSendMessage(answer);
  };

  // Quick suggestion chips based on missing fields
  const quickChips = [
    'Main Library, 2nd Floor East Wing Study Pods',
    'Science Complex B, 1st Floor Lab 104',
    'Engineering Hall, 2nd Floor Room 202',
    'Student Center, 1st Floor South Concourse Entrance',
    'It is active right now and getting worse',
    'Small slow drip, not flooding yet'
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Step Indicator Header */}
      <div className="bg-white rounded-[20px] border border-[#DCE6F0] p-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#0D9488] uppercase tracking-wider">
              <span>Step 2 of 4</span>
              <span aria-hidden="true">·</span>
              <span>AI Follow-Up Clarification</span>
            </div>
            <h1 className="text-xl md:text-2xl font-bold text-[#17324F] mt-1">
              {currentAnalysis.isMissingEssentialInfo
                ? 'A Few Additional Details Needed'
                : 'Ticket Details Clarified'}
            </h1>
            <p className="text-xs md:text-sm text-[#17324F]/70 mt-1">
              Gemini analyzed your complaint and identified the category and symptoms.
              {currentAnalysis.isMissingEssentialInfo
                ? ' Please clarify the highlighted questions so maintenance crews know exactly where to dispatch.'
                : ' All essential campus facility details have been captured.'}
            </p>
          </div>

          <button
            onClick={onRestart}
            className="text-xs font-semibold text-[#123456] bg-white hover:bg-[#F3F7FB] border border-[#DCE6F0] transition-all px-3.5 py-1.5 rounded-full flex items-center gap-1.5 cursor-pointer shadow-2xs hover:shadow-xs active:scale-[0.99]"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Start Over</span>
          </button>
        </div>

        {/* Current Assessment Strip */}
        <div className="mt-4 pt-4 border-t border-[#DCE6F0] grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-[14px] bg-[#F3F7FB] border border-[#DCE6F0]">
            <span className="text-[#17324F]/60 block text-[11px]">Category</span>
            <div className="flex items-center gap-1.5 font-semibold text-[#17324F] mt-0.5">
              <CategoryIcon category={currentAnalysis.category} className="w-3.5 h-3.5" />
              <span>{currentAnalysis.category}</span>
            </div>
          </div>

          <div className="p-3 rounded-[14px] bg-[#F3F7FB] border border-[#DCE6F0]">
            <span className="text-[#17324F]/60 block text-[11px]">Department</span>
            <div className="font-semibold text-[#17324F] mt-0.5 truncate" title={currentAnalysis.assignedDepartment}>
              {currentAnalysis.assignedDepartment}
            </div>
          </div>

          <div className="p-3 rounded-[14px] bg-[#F3F7FB] border border-[#DCE6F0]">
            <span className="text-[#17324F]/60 block text-[11px]">Priority</span>
            <div className="mt-0.5">
              <PriorityBadge priority={currentAnalysis.priority} size="sm" />
            </div>
          </div>

          <div className="p-3 rounded-[14px] bg-[#F3F7FB] border border-[#DCE6F0]">
            <span className="text-[#17324F]/60 block text-[11px]">Information Status</span>
            <div className="font-semibold mt-0.5">
              {currentAnalysis.isMissingEssentialInfo ? (
                <span className="text-amber-700 flex items-center gap-1">
                  <HelpCircle className="w-3 h-3" /> Clarifying
                </span>
              ) : (
                <span className="text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Ready
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Safety Warning if detected */}
        {currentAnalysis.isSafetyHazard && (
          <div className="mt-4">
            <HazardNotice warning={currentAnalysis.safetyWarning} />
          </div>
        )}
      </div>

      {/* Conversation Thread */}
      <div className="bg-white rounded-[20px] border border-[#DCE6F0] overflow-hidden shadow-xs">
        <div className="px-6 py-3.5 bg-[#F3F7FB] border-b border-[#DCE6F0] flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#17324F]">
            <MessageSquare className="w-4 h-4 text-[#0D9488]" />
            <span>Clarification Conversation Thread</span>
          </div>
          <span className="text-xs text-[#17324F]/60 font-mono">Gemini 3.8 Flash Context</span>
        </div>

        <div className="p-6 space-y-4 max-h-[420px] overflow-y-auto">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${
                msg.role === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div className="flex items-center gap-1.5 text-[11px] text-[#17324F]/60 mb-1 px-1">
                <span>{msg.role === 'user' ? 'You (Alex Chen)' : 'CampusFix AI'}</span>
                <span aria-hidden="true">·</span>
                <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <div
                className={`max-w-[85%] rounded-[16px] p-3.5 text-xs sm:text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-[#123456] text-white font-medium rounded-tr-none'
                    : 'bg-teal-50/70 border border-[#DCE6F0] text-[#17324F] rounded-tl-none'
                }`}
              >
                {msg.content}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-xs text-[#0D9488] bg-teal-50/50 p-3 rounded-[14px] border border-teal-100 max-w-[80%] animate-pulse">
              <Sparkles className="w-4 h-4 animate-spin text-[#0D9488]" />
              <span>Gemini is evaluating your clarification and updating ticket fields...</span>
            </div>
          )}
        </div>

        {/* Quick Answer Chips */}
        {currentAnalysis.isMissingEssentialInfo && (
          <div className="px-6 py-3 bg-[#F3F7FB] border-t border-[#DCE6F0]">
            <span className="text-[11px] font-semibold text-[#17324F]/70 uppercase tracking-wider block mb-1.5">
              Quick Suggestions:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {quickChips.map((chip, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleQuickAnswer(chip)}
                  disabled={isLoading}
                  className="px-3 py-1 text-xs rounded-full bg-white border border-[#DCE6F0] text-[#123456] hover:bg-[#F3F7FB] hover:border-[#0D9488] transition-all cursor-pointer shadow-2xs hover:shadow-xs active:scale-[0.99]"
                >
                  {chip}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Bar or Proceed Banner */}
        <div className="p-4 bg-white border-t border-[#DCE6F0]">
          {currentAnalysis.isMissingEssentialInfo ? (
            <form onSubmit={handleSend} className="flex gap-2">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Type your clarification (e.g. 2nd floor, Room 204 near the water fountain)..."
                disabled={isLoading}
                className="flex-1 px-4 py-2 text-xs sm:text-sm rounded-[14px] border border-[#DCE6F0] focus:outline-none focus:ring-2 focus:ring-[#0D9488] focus:border-[#0D9488] text-[#17324F]"
              />
              <button
                type="submit"
                disabled={isLoading || !replyText.trim()}
                className="inline-flex items-center gap-1.5 px-5 py-2 rounded-full bg-[#0D9488] hover:bg-[#0B7C72] disabled:opacity-50 text-white font-medium text-xs sm:text-sm transition-all cursor-pointer shadow-xs active:scale-[0.99]"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send</span>
              </button>
            </form>
          ) : (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-2">
              <div className="flex items-center gap-2 text-xs font-medium text-emerald-800">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Location and defect details confirmed. Ready to review ticket.</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  soundFx.success();
                  onProceedToReview();
                }}
                className="inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-full bg-[#0D9488] hover:bg-[#0B7C72] text-white font-medium text-xs sm:text-sm shadow-xs transition-all focus:outline-none focus:ring-2 focus:ring-[#0D9488] focus:ring-offset-2 cursor-pointer active:scale-[0.99]"
              >
                <span>Review Structured Ticket</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
