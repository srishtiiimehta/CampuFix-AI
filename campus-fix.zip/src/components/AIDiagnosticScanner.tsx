import React, { useState } from 'react';
import { Sparkles, Eye, ShieldAlert, Cpu, CheckCircle2, RotateCw } from 'lucide-react';
import { soundFx } from '../services/soundFx';

interface Hotspot {
  id: string;
  xPercent: number;
  yPercent: number;
  label: string;
  detail: string;
  confidence: number;
  severity: 'low' | 'medium' | 'critical';
}

interface AIDiagnosticScannerProps {
  imageUrl: string;
  category?: string;
  observations?: string[];
  inferences?: string[];
}

export const AIDiagnosticScanner: React.FC<AIDiagnosticScannerProps> = ({
  imageUrl,
  category = 'Campus Maintenance',
  observations = [],
  inferences = []
}) => {
  const [isScanning, setIsScanning] = useState(false);
  const [selectedHotspot, setSelectedHotspot] = useState<string | null>('hot-1');
  const [scannerActive, setScannerActive] = useState(true);

  // Derive dynamic hotspots based on category
  const hotspots: Hotspot[] = category.includes('Plumbing')
    ? [
        {
          id: 'hot-1',
          xPercent: 42,
          yPercent: 35,
          label: 'Primary Fluid Leak',
          detail: 'High pressure spray detected at pipe coupling fitting.',
          confidence: 96,
          severity: 'critical'
        },
        {
          id: 'hot-2',
          xPercent: 58,
          yPercent: 68,
          label: 'Floor Water Pooling',
          detail: 'Liquid pooling spreading across tile surface towards cabinetry.',
          confidence: 93,
          severity: 'medium'
        }
      ]
    : category.includes('Cleanliness')
    ? [
        {
          id: 'hot-1',
          xPercent: 50,
          yPercent: 48,
          label: 'Shattered Ceramic Fragments',
          detail: 'Sharp shard scatter zone posing puncture and cut hazard.',
          confidence: 97,
          severity: 'critical'
        },
        {
          id: 'hot-2',
          xPercent: 35,
          yPercent: 62,
          label: 'Liquid Slip Threshold',
          detail: 'High gloss spill surface creating severe friction loss on floor.',
          confidence: 94,
          severity: 'critical'
        }
      ]
    : category.includes('Electricity')
    ? [
        {
          id: 'hot-1',
          xPercent: 48,
          yPercent: 32,
          label: 'Capacitor Discoloration',
          detail: 'Thermal stress marking and high-frequency luminaire arc detected.',
          confidence: 92,
          severity: 'medium'
        }
      ]
    : [
        {
          id: 'hot-1',
          xPercent: 50,
          yPercent: 45,
          label: 'Access Point Dropped Packets',
          detail: 'Ping loss telemetry indicates 82% drop rate on 5GHz radio channel.',
          confidence: 95,
          severity: 'medium'
        }
      ];

  const handleTriggerRescan = () => {
    soundFx.click();
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      soundFx.success();
    }, 1200);
  };

  const activeSpot = hotspots.find((h) => h.id === selectedHotspot) || hotspots[0];

  return (
    <div className="rounded-[16px] bg-[#F3F7FB] border border-[#DCE6F0] p-4 space-y-3">
      {/* Scanner header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-[#0D9488]/15 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-[#0D9488]" />
          </div>
          <div>
            <span className="text-xs font-bold text-[#17324F] block">
              Gemini Multimodal AI Vision Inspector
            </span>
            <span className="text-[10px] text-[#17324F]/70 font-mono">
              Live Neural Defect Extraction & Anomaly Heatmap
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              soundFx.click();
              setScannerActive(!scannerActive);
            }}
            className={`px-3 py-1 rounded-full text-[11px] font-semibold border transition-all cursor-pointer ${
              scannerActive
                ? 'bg-[#0D9488] text-white border-[#0D9488]'
                : 'bg-white text-[#17324F] border-[#DCE6F0]'
            }`}
          >
            {scannerActive ? 'Overlay Active' : 'Normal Photo'}
          </button>

          <button
            type="button"
            onClick={handleTriggerRescan}
            disabled={isScanning}
            title="Re-run neural scan on image"
            className="p-1.5 rounded-full bg-white hover:bg-slate-100 text-[#17324F] border border-[#DCE6F0] transition-all cursor-pointer"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin text-[#0D9488]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main visual viewport */}
      <div className="relative rounded-[14px] overflow-hidden border border-[#DCE6F0] bg-slate-950 aspect-video">
        <img
          src={imageUrl}
          alt="Visual Evidence"
          className="w-full h-full object-cover select-none"
        />

        {/* Animated Scanning Beam Overlay */}
        {scannerActive && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div
              className={`absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-[#0D9488] to-transparent shadow-[0_0_15px_#0D9488] opacity-75 ${
                isScanning ? 'animate-bounce duration-1000' : 'animate-pulse'
              }`}
              style={{ top: '45%' }}
            />
            {/* Tech grid overlay */}
            <div
              className="absolute inset-0 opacity-15"
              style={{
                backgroundImage:
                  'radial-gradient(circle, rgba(255,255,255,0.3) 1px, transparent 1px)',
                backgroundSize: '20px 20px',
              }}
            />
          </div>
        )}

        {/* Interactive Hotspot Markers */}
        {scannerActive &&
          hotspots.map((spot) => (
            <button
              key={spot.id}
              type="button"
              onClick={() => {
                soundFx.click();
                setSelectedHotspot(spot.id);
              }}
              style={{ left: `${spot.xPercent}%`, top: `${spot.yPercent}%` }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-transform ${
                selectedHotspot === spot.id ? 'scale-125 z-20' : 'scale-100 z-10 hover:scale-110'
              }`}
            >
              <span className="relative flex h-6 w-6">
                <span
                  className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                    spot.severity === 'critical' ? 'bg-rose-400' : 'bg-[#0D9488]'
                  }`}
                />
                <span
                  className={`relative inline-flex rounded-full h-6 w-6 items-center justify-center text-[10px] font-bold text-white shadow-md border-2 border-white ${
                    spot.severity === 'critical' ? 'bg-rose-600' : 'bg-[#0D9488]'
                  }`}
                >
                  !
                </span>
              </span>
            </button>
          ))}

        {/* Live scanning badge */}
        <div className="absolute bottom-2 left-2 px-2.5 py-0.5 rounded-full bg-slate-900/80 backdrop-blur-xs text-[10px] font-mono text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          <span>Gemini Vision 3.8 Multimodal</span>
        </div>
      </div>

      {/* Selected hotspot card */}
      {scannerActive && activeSpot && (
        <div className="p-3 rounded-[12px] bg-white border border-[#DCE6F0] flex items-start justify-between gap-3 text-xs">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-[#17324F]">{activeSpot.label}</span>
              <span
                className={`text-[10px] font-bold px-2 py-0.2 rounded-full font-mono ${
                  activeSpot.severity === 'critical'
                    ? 'bg-rose-100 text-rose-800'
                    : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                {activeSpot.confidence}% Match
              </span>
            </div>
            <p className="text-[11px] text-[#17324F]/75 mt-0.5">{activeSpot.detail}</p>
          </div>
          <span className="text-[10px] font-mono text-[#0D9488] shrink-0 font-semibold uppercase">
            Point Verified
          </span>
        </div>
      )}
    </div>
  );
};
