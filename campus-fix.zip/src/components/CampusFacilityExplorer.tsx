import React, { useState } from 'react';
import { 
  Building2, 
  MapPin, 
  ShieldCheck, 
  AlertTriangle, 
  Activity, 
  CheckCircle2, 
  Clock, 
  Sparkles,
  ChevronRight,
  Filter
} from 'lucide-react';
import { soundFx } from '../services/soundFx';

export interface CampusBuilding {
  id: string;
  name: string;
  code: string;
  categoryTheme: string;
  activeCount: number;
  status: 'normal' | 'maintenance' | 'hazard';
  latestEvent: string;
  inspectionLead: string;
}

interface CampusFacilityExplorerProps {
  selectedBuilding: string | null;
  onSelectBuilding: (buildingName: string | null) => void;
  onQuickReportBuilding?: (buildingName: string) => void;
}

export const CAMPUS_BUILDINGS: CampusBuilding[] = [
  {
    id: 'bldg-lib',
    name: 'Main University Library',
    code: 'LIB',
    categoryTheme: 'Internet Connectivity',
    activeCount: 1,
    status: 'maintenance',
    latestEvent: 'Access point AP-LIB-2E power-cycle in progress',
    inspectionLead: 'David Kim (Network Admin)'
  },
  {
    id: 'bldg-sci',
    name: 'Science Complex B',
    code: 'SCI-B',
    categoryTheme: 'Plumbing',
    activeCount: 1,
    status: 'hazard',
    latestEvent: 'Room 104 emergency shutoff valve isolated & safe',
    inspectionLead: 'Robert Santos (Lead Plumber)'
  },
  {
    id: 'bldg-eng',
    name: 'Engineering Hall',
    code: 'ENG',
    categoryTheme: 'Electricity',
    activeCount: 1,
    status: 'maintenance',
    latestEvent: 'Hall 202 ballast replacement scheduled 3:00 PM',
    inspectionLead: 'Marcus Vance (Facilities Lead)'
  },
  {
    id: 'bldg-stu',
    name: 'Student Activity Center',
    code: 'SAC',
    categoryTheme: 'Cleanliness',
    activeCount: 0,
    status: 'normal',
    latestEvent: 'Concourse spill sanitized, dry & floor buffed',
    inspectionLead: 'Maria Gomez (Housekeeping Supv)'
  },
  {
    id: 'bldg-jhn',
    name: 'Johnson Residence Quad',
    code: 'JHN',
    categoryTheme: 'General Facilities',
    activeCount: 0,
    status: 'normal',
    latestEvent: 'Weekly preventive maintenance check verified',
    inspectionLead: 'Marcus Vance (Facilities Lead)'
  }
];

export const CampusFacilityExplorer: React.FC<CampusFacilityExplorerProps> = ({
  selectedBuilding,
  onSelectBuilding,
  onQuickReportBuilding,
}) => {
  const [tickerIndex, setTickerIndex] = useState(0);

  const tickerDispatches = [
    '⚡ Crew #2 completed electrical verification in Engineering Hall 202',
    '💧 Science Complex B water line isolated; dry certificate issued',
    '📶 Network operations monitoring AP-LIB-2E packet rates at 480 Mbps',
    '✨ Student Center concourse verified slip-free by Housekeeping Lead'
  ];

  return (
    <div className="bg-white rounded-[20px] border border-[#DCE6F0] p-5 shadow-xs space-y-4">
      {/* Top Banner & Live Pulse */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#DCE6F0]">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-[#0D9488]/10 flex items-center justify-center text-[#0D9488]">
            <Activity className="w-4 h-4 text-[#0D9488] animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-[#17324F]">
                Campus Facility Live Status & Building Radar
              </h2>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-700 border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                94% Normal
              </span>
            </div>
            <p className="text-xs text-[#17324F]/70">
              Select any building to filter active tickets, inspect ongoing repairs, or report an issue.
            </p>
          </div>
        </div>

        {selectedBuilding && (
          <button
            type="button"
            onClick={() => {
              soundFx.click();
              onSelectBuilding(null);
            }}
            className="self-start sm:self-auto inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold text-[#0D9488] bg-[#0D9488]/10 hover:bg-[#0D9488]/20 transition-all cursor-pointer"
          >
            <span>Reset Building Filter</span>
            <span className="font-mono text-[10px]">&times;</span>
          </button>
        )}
      </div>

      {/* Buildings Interactive Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
        {CAMPUS_BUILDINGS.map((bldg) => {
          const isSelected = selectedBuilding === bldg.name;
          const isHazard = bldg.status === 'hazard';
          const isMaint = bldg.status === 'maintenance';

          return (
            <button
              key={bldg.id}
              type="button"
              onClick={() => {
                soundFx.click();
                onSelectBuilding(isSelected ? null : bldg.name);
              }}
              className={`p-3 rounded-[16px] text-left transition-all border cursor-pointer group relative ${
                isSelected
                  ? 'border-[#0D9488] ring-2 ring-[#0D9488]/20 bg-[#F3F7FB] shadow-xs'
                  : 'border-[#DCE6F0] bg-white hover:bg-[#F3F7FB] hover:border-[#0D9488]/40'
              }`}
            >
              {/* Status Indicator Dot */}
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-black/5 text-[#17324F]/70">
                  {bldg.code}
                </span>

                <span className="relative flex h-2.5 w-2.5">
                  {isHazard ? (
                    <>
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500" />
                    </>
                  ) : isMaint ? (
                    <>
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500" />
                    </>
                  ) : (
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
                  )}
                </span>
              </div>

              <div className="font-bold text-xs text-[#17324F] group-hover:text-[#0D9488] line-clamp-1 transition-colors">
                {bldg.name}
              </div>

              <div className="text-[10px] text-[#17324F]/60 mt-1 flex items-center justify-between">
                <span>{bldg.activeCount > 0 ? `${bldg.activeCount} In Progress` : 'All Systems OK'}</span>
                {isSelected && <CheckCircle2 className="w-3 h-3 text-[#0D9488]" />}
              </div>
            </button>
          );
        })}
      </div>

      {/* Live Dispatch Ticker */}
      <div className="p-2.5 rounded-[14px] bg-[#F3F7FB] border border-[#DCE6F0] flex items-center justify-between gap-3 text-xs text-[#17324F]">
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-[#0D9488] shrink-0 bg-white px-2 py-0.5 rounded-full border border-[#DCE6F0]">
            Live Dispatch
          </span>
          <span className="text-[11px] text-[#17324F]/80 truncate">
            {tickerDispatches[tickerIndex]}
          </span>
        </div>

        <button
          type="button"
          onClick={() => {
            soundFx.click();
            setTickerIndex((prev) => (prev + 1) % tickerDispatches.length);
          }}
          className="text-[10px] font-mono font-medium text-[#17324F]/60 hover:text-[#0D9488] shrink-0 cursor-pointer"
        >
          Next Update ›
        </button>
      </div>
    </div>
  );
};
